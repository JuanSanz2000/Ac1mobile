# Assassin's Creed — Al-Masyaf  
## Proyecto Android — Instrucciones de compilación

---

## OPCIÓN 1: Android Studio (recomendado, más fácil)

### Requisitos
- [Android Studio](https://developer.android.com/studio) (gratuito)
- JDK 17+ (viene incluido con Android Studio)

### Pasos
1. Abre Android Studio
2. **File → Open** → selecciona esta carpeta (`ac_android`)
3. Espera a que Gradle sincronice (1-2 minutos, descarga dependencias)
4. Menú: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. El APK se genera en: `app/build/outputs/apk/debug/app-debug.apk`
6. Copia el APK a tu Xiaomi o instala directamente con USB

### Instalar en Xiaomi
1. En el teléfono: **Ajustes → Privacidad → Instalar apps desconocidas → Chrome/Gestor archivos → Activar**
2. Copia el `.apk` al teléfono (cable USB o Google Drive)
3. Ábrelo y pulsa **Instalar**

---

## OPCIÓN 2: Línea de comandos (sin Android Studio)

### Requisitos
- JDK 17+: https://adoptium.net/
- Android SDK command-line tools: https://developer.android.com/tools
- `sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"`

### Compilar
```bash
# En Mac/Linux
chmod +x gradlew
./gradlew assembleDebug

# En Windows
gradlew.bat assembleDebug
```

APK generado en: `app/build/outputs/apk/debug/app-debug.apk`

---

## OPCIÓN 3: GitHub Actions (compilación en la nube, sin instalar nada)

1. Crea un repo en GitHub y sube esta carpeta
2. Crea `.github/workflows/build.yml`:

```yaml
name: Build APK
on: [push]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-java@v3
        with:
          java-version: '17'
          distribution: 'temurin'
      - name: Build APK
        run: |
          chmod +x gradlew
          ./gradlew assembleDebug
      - uses: actions/upload-artifact@v3
        with:
          name: assassins-creed.apk
          path: app/build/outputs/apk/debug/app-debug.apk
```

3. Haz push → Actions → descarga el APK generado

---

## Estructura del proyecto

```
ac_android/
├── app/
│   ├── src/main/
│   │   ├── assets/www/
│   │   │   └── index.html          ← El juego completo
│   │   ├── java/com/altair/creed/
│   │   │   └── MainActivity.java   ← WebView fullscreen
│   │   ├── res/
│   │   │   ├── mipmap-*/           ← Iconos del launcher
│   │   │   └── values/             ← Tema negro fullscreen
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── gradle/wrapper/
├── build.gradle
├── settings.gradle
└── README.md
```

---

## Características del juego
- Pantalla completa sin barras del sistema (modo inmersivo)
- Controles táctiles optimizados para móvil
- Se mantiene la pantalla encendida mientras juegas
- Sin conexión a internet requerida
- Compatible con Android 5.0+ (API 21)

---

*"Nada es verdad, todo está permitido." — Altaïr Ibn-La'Ahad*
